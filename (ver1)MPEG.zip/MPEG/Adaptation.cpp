#include "header.h"

byte* AdaptationField::setting(byte* TSptr)
{
	byte* base_ptr = TSptr;
	byte* ptr = TSptr;
	
	if(PCR_flag)		
	{
		PCR_base = ptr[0]*0x2000000 + ptr[1]*0x20000 + ptr[2]*0x200 + ptr[3]*0x02 + ((ptr[4] & 0x80)>>7);
		PCR_reserved = (ptr[4]&0x7E)>>1;
		PCR_extension = (ptr[4] &0x01) * 0x100 + ptr[5];

		*ptr += 6;
	}

	if(OPCR_flag)
	{
		OPCR_base = ptr[0]*0x2000000 + ptr[1]*0x20000 + ptr[2]*0x200 + ptr[3]*0x02 + ((ptr[4] & 0x80)>>7);
		OPCR_reserved = (ptr[4]&0x7E)>>1;
		OPCR_extension = (ptr[4] &0x01) * 0x100 + ptr[5];

		*ptr += 6;
	}

	if(splicing_flag)
	{
		splice_countdown = ptr[0];

		*ptr += 1;
	}

	if(transport_private_data_flag)
	{
		transport_private_data_length = ptr[0];

		*ptr += 1;

		if(transport_private_data_length)
		{
			transport_private_data = (byte*)calloc(transport_private_data_length +1, sizeof(byte));
			for(int i=0; i< (int)transport_private_data_length; i++)
				*transport_private_data = ptr[i];

			*ptr += transport_private_data_length;
		}
	}

	if(adaptation_field_extension_flag)
	{
		adaptation_field_length = ptr[0];

		ltw_flag = (ptr[1]&0x80)>>7;

		piecewise_rate_flag = (ptr[1]&0x40)>>6;

		seamless_splice_flag = (ptr[1]&0x20)>>5;

		reserved_1 = (ptr[1]*0x1F);

		*ptr +=2;

		if(ltw_flag)
		{
			ltw_valid_flag = (ptr[0]&0x80)>>7;
			
			ltw_offset = (ptr[0]&0x7F)*0x100 + ptr[1];
	
			*ptr += 2;
		}

		if(piecewise_rate_flag)
		{
			reserved_2 = (ptr[0]&0xC0)>>6;	 //???????????????????????
			
			piecewise_rate = ((ptr[0]&30)>>4)*0x200 + ptr[1]*0x02 + ptr[2];
			printf("%04x \n", piecewise_rate);
	
			*ptr += 3;
		}

		if(seamless_splice_flag)
		{
			splice_type = (ptr[0]&0xF0)>>4;

			DTS_next_au_32_30 = (ptr[0]&0x0E) >> 1;

			DTS_next_au_29_15 = (ptr[1]&0xFE) >> 1;

			DTS_next_au_14_0 = (ptr[2]&0xFE) >> 1;

			*ptr += 3;
		}	
	}
	
	*ptr = *base_ptr + adaptation_field_length;
	return ptr;
}
/*
byte*  AdaptationField::getPtr()
{
	return ptr;
}
*/