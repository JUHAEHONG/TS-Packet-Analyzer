// MPEGDlg.cpp : ���� ����
//
#include "stdafx.h"
#include "MPEG.h"
#include "MPEGDlg.h"
#include "afxdialogex.h"
#include "header.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CFile infile;
Packet pk;
PSI psi;
CFont font;

// ���� ���α׷� ������ ���Ǵ� CAboutDlg ��ȭ �����Դϴ�.
class CAboutDlg : public CDialogEx
{
public:

	CAboutDlg();
	// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_ABOUTBOX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	// �����Դϴ�.
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{

}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);

}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()
// CMPEGDlg ��ȭ ����
// �ʱ�ȭ
CMPEGDlg::CMPEGDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CMPEGDlg::IDD, pParent)
	, User_PID(_T(""))
	, User_PacketNumber(_T(""))
	, intSyncByte(_T(""))
	, intPID(_T(""))
	, intTransportErrorIndicator(_T(""))
	, intTransportScrambling(_T(""))
	, intPayloadUnitStart(_T(""))
	, intAdaptationFieldControl(_T(""))
	, intTransportPriority(_T(""))
	, intContinuityCounter(_T(""))
	, intFileSize(0)
	, intFileNumberOfPackets(0)
	, intFileErrorPackets(0)
	, intFileNormalPackets(0)
	, countError(0)
	, PacketData1(_T(""))
	, PkIndex(_T(""))
	, listIndex(0)
	, PSIinfo(_T(""))
	, thisID(0)
	, intSearchPID(0)
	, blankCount(0)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_pwndShow = NULL; //listcontrol show �ʱ����

}

void CMPEGDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);


	//�ڽ��� ���� ����ϱ�

	DDX_Text(pDX, SyncByte, intSyncByte);
	DDX_Text(pDX, TransportErrorIndicator, intTransportErrorIndicator);
	DDX_Text(pDX, PayloadUnitStart, intPayloadUnitStart);
	DDX_Text(pDX, TransportPriority, intTransportPriority);
	DDX_Text(pDX, PID, intPID);
	DDX_Text(pDX, TransportScrambling, intTransportScrambling);
	DDX_Text(pDX, AdaptationFieldControl, intAdaptationFieldControl);
	DDX_Text(pDX, ContinuityCounter, intContinuityCounter);
	DDX_Text(pDX, Search_PID , intSearchPID);
	DDX_Text(pDX, Search_PacketNumber, intSearchPacketNumber);
	DDX_Text(pDX, File_Size, intFileSize);
	DDX_Text(pDX, File_NumOfPackets, intFileNumberOfPackets);
	DDX_Text(pDX, File_NormalPackets, intFileNormalPackets);
	DDX_Text(pDX, File_ErrorPackets, intFileErrorPackets);
	DDX_Text(pDX, SelectedPacket, thisID);

	DDX_Text(pDX, PacketMap, PSIinfo);

	DDX_Control(pDX, IDC_BUTTON1, Button1);
	DDX_Text(pDX, Search_PID, User_PID); 
	DDX_Text(pDX, Search_PacketNumber, User_PacketNumber);
	DDX_Control(pDX, TS_list, TS_listcontrol);
	DDX_Control(pDX, IDC_BUTTON2, Button2);
	DDX_Control(pDX, IDC_BUTTON4, Button4);
	DDX_Control(pDX, ES_list, ES_listcontrol);
}

BEGIN_MESSAGE_MAP(CMPEGDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_EN_CHANGE(Search_PID, &CMPEGDlg::OnEnChangePid)
	ON_LBN_SELCHANGE(Packetdata_list, &CMPEGDlg::OnLbnSelchangelist)
	ON_COMMAND(ID_FILE_OPEN32772, &CMPEGDlg::OnFileOpen_FileOpen)
	ON_BN_CLICKED(IDC_BUTTON1, &CMPEGDlg::OnBnClickedPIDSearchButton)
	ON_BN_CLICKED(IDC_BUTTON2, &CMPEGDlg::OnBnClickedPacketNumSearchButton)
	ON_NOTIFY(LVN_ITEMCHANGED, TS_list, &CMPEGDlg::OnLvnItemchangedlist)
	ON_NOTIFY(NM_CLICK, TS_list, &CMPEGDlg::OnNMClicklist)
	ON_EN_CHANGE(PacketMap, &CMPEGDlg::OnEnChangePacketmap)
	ON_COMMAND(ID_MENU_ESMODE, &CMPEGDlg::OnMenuEsmode_ESMode)
	ON_NOTIFY(NM_CUSTOMDRAW, TS_list, &CMPEGDlg::OnNMCustomdrawlist_TSlist)
	ON_NOTIFY(NM_CUSTOMDRAW, ES_list, &CMPEGDlg::OnNMCustomdrawlist_ESlist)
	ON_COMMAND(ID_MENU_PACKETMODE, &CMPEGDlg::OnMenuPacketmode_PacketMode)
	ON_BN_CLICKED(IDC_BUTTON4, &CMPEGDlg::OnBnClickedESSearchButton)
END_MESSAGE_MAP()


// CMPEGDlg �޽��� ó����
BOOL CMPEGDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	ES_listcontrol.ShowWindow(SW_HIDE);
	// �ý��� �޴��� "����..." �޴� �׸��� �߰��մϴ�.

	// IDM_ABOUTBOX�� �ý��� ���� ������ �־�� �մϴ�.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// �� ��ȭ ������ �������� �����մϴ�. ���� ���α׷��� �� â�� ��ȭ ���ڰ� �ƴ� ��쿡��
	//  �����ӿ�ũ�� �� �۾��� �ڵ����� �����մϴ�.
	SetIcon(m_hIcon, TRUE);         // ū �������� �����մϴ�.
	SetIcon(m_hIcon, FALSE);      // ���� �������� �����մϴ�.

	// TODO: ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.

	//button image 
	Button1.LoadBitmaps(IDB_BITMAP2,NULL,NULL,NULL);
	Button1.SizeToContent();

	Button2.LoadBitmaps(IDB_BITMAP2,NULL,NULL,NULL);
	Button2.SizeToContent();

	Button4.LoadBitmaps(IDB_BITMAP2,NULL,NULL,NULL);
	Button4.SizeToContent();

	font.CreateFont(14, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, DEFAULT_CHARSET,
		OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS,
		_T("Consolas"));
	TS_listcontrol.SetFont(&font);

	TS_listcontrol.DeleteAllItems(); // ����Ʈ �ʱ�ȭ 
	TS_listcontrol.SetExtendedStyle(LVS_EX_FULLROWSELECT); // ���ñ�� Ȱ��ȭ
	TS_listcontrol.SetExtendedStyle(LVS_EX_GRIDLINES);  // ����Ʈ ��Ÿ�� ����

	//List Control ��� ���� 
	TS_listcontrol.InsertColumn(0,_T("Packet No"), LVCFMT_RIGHT, 90);
	TS_listcontrol.InsertColumn(1,_T("Packet Data"), LVCFMT_LEFT, 1275);   
	TS_listcontrol.InsertColumn(2,_T("Packet Data"), LVCFMT_LEFT, 1275);
	TS_listcontrol.InsertColumn(3,_T("Packet Data"), LVCFMT_LEFT, 1450);

	return TRUE;  // ��Ŀ���� ��Ʈ�ѿ� �������� ������ TRUE�� ��ȯ�մϴ�.
}

void CMPEGDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// ��ȭ ���ڿ� �ּ�ȭ ���߸� �߰��� ��� �������� �׸�����
//  �Ʒ� �ڵ尡 �ʿ��մϴ�. ����/�� ���� ����ϴ� MFC ���� ���α׷��� ��쿡��
//  �����ӿ�ũ���� �� �۾��� �ڵ����� �����մϴ�.

void CMPEGDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // �׸��⸦ ���� ����̽� ���ؽ�Ʈ�Դϴ�.

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Ŭ���̾�Ʈ �簢������ �������� ����� ����ϴ�.
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// �������� �׸��ϴ�.
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// ����ڰ� �ּ�ȭ�� â�� ���� ���ȿ� Ŀ���� ǥ�õǵ��� �ý��ۿ���
//  �� �Լ��� ȣ���մϴ�.
HCURSOR CMPEGDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CMPEGDlg::OnEnChangePid()
{
	// TODO:  RICHEDIT ��Ʈ���� ���, �� ��Ʈ����
	// CDialogEx::OnInitDialog() �Լ��� ������ 
	//�ϰ� ����ũ�� OR �����Ͽ� ������ ENM_CHANGE �÷��׸� �����Ͽ� CRichEditCtrl().SetEventMask()�� ȣ������ ������
	// �� �˸� �޽����� ������ �ʽ��ϴ�.

	// TODO:  ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
}


void CMPEGDlg::OnLbnSelchangelist()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
}


void CMPEGDlg::OnFileOpen_FileOpen() //file open �޴� Ŭ��
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	CString CFilename; // ���� �޾ƿ���

	infile.Close();				
	TS_listcontrol.DeleteAllItems();

	CString str = _T("MPG(*.mpg)|*.mpg");
	CFileDialog fileDlg(TRUE, NULL, NULL, OFN_HIDEREADONLY, str);


	if(fileDlg.DoModal() == IDOK)
	{
		blankIndex = (int**)malloc(sizeof(int)*intFileNumberOfPackets);		//ES data�� ��Ŷ���� �����ϱ� ���� �������迭 �����Ҵ�(10000*2)
		for(int c=0; c<intFileNumberOfPackets; c++)
		{
			blankIndex[c] = (int *)malloc(sizeof(int)*2);
		}
	
		if(!infile.Open(fileDlg.GetPathName(), CFile::modeRead | CFile::typeBinary))
		{
			exit(1);
		}
		byte buf[PACKETSIZE];
		infile.Seek(sizeof(byte)*thisID*PACKETSIZE, infile.begin);
		infile.Read(buf, sizeof(byte)*PACKETSIZE);
		pk.readData(buf, thisID);

		char temp[10];
		sprintf(temp, "%04x", pk.sync_byte);
		intSyncByte += temp;


		sprintf(temp, "%x", pk.transport_error_indicator);
		intTransportErrorIndicator += temp;

		sprintf(temp, "%x", pk.payload_unit_start_indicator);
		intPayloadUnitStart += temp;

		sprintf(temp, "%x", pk.transport_priority);
		intTransportPriority += temp;

		sprintf(temp, "%04x", pk.pid);
		intPID += temp;

		sprintf(temp, "%02x", pk.transport_scrambling_control);
		intTransportScrambling += temp;

		sprintf(temp, "%02x", pk.adaptation_field_control);
		intAdaptationFieldControl += temp;

		sprintf(temp, "%d", pk.continuity_counter);
		intContinuityCounter += temp;

		//Get File size
		intFileSize = infile.GetLength();
		intFileNumberOfPackets = (infile.GetLength())/PACKETSIZE;


		//****************************PSI****************************
		if(pk.pid == 0 || pk.pid == 1 || pk.pid==4128)   //PSI or TS
		{
			psi.calculatePSI(pk.pkData, pk.pid);

			char name[30];
			char tempPSI[40];

			//case of PSI
			switch(pk.pid)
			{
			case 0:      //PAT
				sprintf(name, "%s", "PAT(Program Allocation Table)");
				PSIinfo += name;
				PSIinfo += "\r\n";
				break;
			case 1:      //CAT
				sprintf(name, "%s", "CAT(Conditional Access Table)");
				PSIinfo += name;
				PSIinfo += "\r\n";
				break;
			case 4128:   //PMT
				sprintf(name, "%s", "PMT(Program Map Table)");
				PSIinfo += name;
				PSIinfo += "\r\n";
				break;
			default:
				break;
			}
			
			//first common data
			sprintf(name, "%s", "table id : ");
			sprintf(tempPSI, "%X", psi.table_id);
			PSIinfo += name;
			PSIinfo += tempPSI;
			PSIinfo += "\r\n";

			sprintf(name, "%s", "section syntax indicator : ");
			sprintf(tempPSI, "%X", psi.section_syntax_indicator);
			PSIinfo += name;
			PSIinfo += tempPSI;
			PSIinfo += "\r\n";

			sprintf(name, "%s", "section length : ");
			sprintf(tempPSI, "%X", psi.section_length);
			PSIinfo += name;
			PSIinfo += tempPSI;
			PSIinfo += "\r\n";

			//first divide data
			switch(pk.pid)
			{
			case 0:      //PAT
				sprintf(name, "%s", "transport stream id : ");
				sprintf(tempPSI, "%X", psi.transport_stream_id);
				PSIinfo += name;
				PSIinfo += tempPSI;
				PSIinfo += "\r\n";
				break;
			case 1:      //CAT
				break;
			case 4128:   //PMT
				sprintf(name, "%s", "program number : ");
				sprintf(tempPSI, "%X", psi.program_number);
				PSIinfo += name;
				PSIinfo += tempPSI;
				PSIinfo += "\r\n";
				break;
			default:
				break;
			}

			//second common data
			sprintf(name, "%s", "version number : ");
			sprintf(tempPSI, "%X", psi.version_number);
			PSIinfo += name;
			PSIinfo += tempPSI;
			PSIinfo += "\r\n";

			sprintf(name, "%s", "current next indicator : ");
			sprintf(tempPSI, "%X", psi.current_next_indicator);
			PSIinfo += name;
			PSIinfo += tempPSI;
			PSIinfo += "\r\n";

			sprintf(name, "%s", "section number : ");
			sprintf(tempPSI, "%X", psi.section_number);
			PSIinfo += name;
			PSIinfo += tempPSI;
			PSIinfo += "\r\n";

			sprintf(name, "%s", "last section number : ");
			sprintf(tempPSI, "%X", psi.last_section_number);
			PSIinfo += name;
			PSIinfo += tempPSI;
			PSIinfo += "\r\n";

			//second divde data
			switch(pk.pid)
			{
			case 0:         // PAT
				if(psi.calculate_length ==0)
					break;
				for(int j=0;j<psi.calculate_length;j++)
				{ 
					if(psi.program_number ==0)
					{
						// network PID 13;   
						sprintf(name, "%s", "program number : ");
						sprintf(tempPSI, "%X", j);
						PSIinfo += name;
						PSIinfo += tempPSI;
						PSIinfo += "\r\n";

						sprintf(name, "%s", "network PID : ");
						sprintf(tempPSI, "%X", psi.network_PID);
						PSIinfo += name;
						PSIinfo += tempPSI;
						PSIinfo += "\r\n";
					}

					else
					{				
						sprintf(name, "%s", "program number : ");
						sprintf(tempPSI, "%X", j);
						PSIinfo += name;
						PSIinfo += tempPSI;
						PSIinfo += "\r\n";

						sprintf(name, "%s", "Program map PID : ");
						sprintf(tempPSI, "%X", psi.program_map_PID);
						PSIinfo += name;
						PSIinfo += tempPSI;
						PSIinfo += "\r\n";
					}

				}
				//CRC32
				sprintf(name, "%s", "CRC32 : ");
				sprintf(tempPSI, "%X", psi.CRC_32);
				PSIinfo += name;
				PSIinfo += tempPSI;
				PSIinfo += "\r\n";
				break;
			case 1:         // CAT
				//CRC32
				sprintf(name, "%s", "CRC32 : ");
				sprintf(tempPSI, "%X", psi.CRC_32);
				PSIinfo += name;
				PSIinfo += tempPSI;
				PSIinfo += "\r\n";
				break;
			case 4128:      // PMT
				if(psi.calculate_length ==0)
					break;
				//etc
				break;
			default:
				break;
			}
		}//end if
		else   //print adaptation / PES
		{
			char name[30];
			char tempAdap[40];

			if(pk.adaptation_field_control == 2 || pk.adaptation_field_control == 3)                     
				// Adaptation field ����
			{
				sprintf(name, "%s", "---Adaptation field---");
				Adapinfo += name;
				Adapinfo += "\r\n";

				sprintf(name, "%s", "adaptation field length : ");
				sprintf(tempAdap, "%x", pk.adaptation_field_length);
				Adapinfo += name;
				Adapinfo += tempAdap;
				Adapinfo += "\r\n";

				sprintf(name, "%s", "PCR flag : ");
				sprintf(tempAdap, "%X", pk.PCR_flag);
				Adapinfo += name;
				Adapinfo += tempAdap;
				Adapinfo += "\r\n";

				sprintf(name, "%s", "PCR : ");
				sprintf(tempAdap, "%u", pk.PCR_base);
				Adapinfo += name;
				Adapinfo += tempAdap;
				Adapinfo += "\r\n";

				if(pk.payload_unit_start_indicator ==1)               
					// PES ����
				{
					char tempPES[40];
					sprintf(name, "%s", "---PES header---");
					PESinfo += name;
					PESinfo += "\r\n";

					sprintf(name, "%s", "packet start code prefix : ");
					sprintf(tempPES, "%X", pk.packet_start_code_prefix);
					PESinfo += name;
					PESinfo += tempPES;
					PESinfo += "\r\n";

					sprintf(name, "%s", "stream id : ");
					sprintf(tempPES, "%X", pk.stream_id);
					PESinfo += name;
					PESinfo += tempPES;
					PESinfo += "\r\n";

					sprintf(name, "%s", "PES packet length : ");
					sprintf(tempPES, "%X", pk.PES_packet_length);
					PESinfo += name;
					PESinfo += tempPES;
					PESinfo += "\r\n";

					sprintf(name, "%s", "PTS/DTS flag : ");
					sprintf(tempPES, "%X", pk.PTS_DTS_flag);
					PESinfo += name;
					PESinfo += tempPES;
					PESinfo += "\r\n";

					if(pk.PTS_DTS_flag == 2)
					{
						sprintf(name, "%s", "PTS : ");
						sprintf(tempPES, "%X", pk.PTS);
						PESinfo += name;
						PESinfo += tempPES;
						PESinfo += "\r\n";
					}
					else if(pk.PTS_DTS_flag ==3)
					{
						sprintf(name, "%s", "PTS : ");
						sprintf(tempPES, "%X", pk.PTS);
						PESinfo += name;
						PESinfo += tempPES;
						PESinfo += "\r\n";

						sprintf(name, "%s", "DTS : ");
						sprintf(tempPES, "%X", pk.DTS);
						PESinfo += name;
						PESinfo += tempPES;
						PESinfo += "\r\n";
					}
					else
					{
						sprintf(name, "%s", "PTS/DTS error !!!");
						PESinfo += name;
						PESinfo += "\r\n";                  
					}
				}
			}
			else
			{
				if(pk.payload_unit_start_indicator ==1)
				{
					char tempPES[40];
					sprintf(name, "%s", "---PES header---");
					PESinfo += name;
					PESinfo += "\r\n";

					sprintf(name, "%s", "packet start code prefix : ");
					sprintf(tempPES, "%X", pk.packet_start_code_prefix);
					PESinfo += name;
					PESinfo += tempPES;
					PESinfo += "\r\n";

					sprintf(name, "%s", "stream id : ");
					sprintf(tempPES, "%X", pk.stream_id);
					PESinfo += name;
					PESinfo += tempPES;
					PESinfo += "\r\n";

					sprintf(name, "%s", "PES packet length : ");
					sprintf(tempPES, "%X", pk.PES_packet_length);
					PESinfo += name;
					PESinfo += tempPES;
					PESinfo += "\r\n";

					sprintf(name, "%s", "PTS/DTS flag : ");
					sprintf(tempPES, "%X", pk.PTS_DTS_flag);
					PESinfo += name;
					PESinfo += tempPES;
					PESinfo += "\r\n";

					if(pk.PTS_DTS_flag == 2)
					{
						sprintf(name, "%s", "PTS : ");
						sprintf(tempPES, "%X", pk.PTS);
						PESinfo += name;
						PESinfo += tempPES;
						PESinfo += "\r\n";
					}
					else if(pk.PTS_DTS_flag ==3)
					{
						sprintf(name, "%s", "PTS : ");
						sprintf(tempPES, "%X", pk.PTS);
						PESinfo += name;
						PESinfo += tempPES;
						PESinfo += "\r\n";

						sprintf(name, "%s", "DTS : ");
						sprintf(tempPES, "%X", pk.DTS);
						PESinfo += name;
						PESinfo += tempPES;
						PESinfo += "\r\n";
					}
					else
					{
						sprintf(name, "%s", "PTS/DTS error !!!");
						PESinfo += name;
						PESinfo += "\r\n";                  
					}
				}
			}
			PSIinfo += Adapinfo;
			PSIinfo += PESinfo;
		/*
			//save ES data
			//ES data ��ġ��			
			CString thisES = _T("");
			//int sizeofThisES = totalESdata.GetLength();
			for(int j=pk.count;j<PACKETSIZE;j++)
			{
				char t[10];
				t[0] =0;
				sprintf(t, "%02X", pk.pkData[j]);
				totalESdata += t;
				sprintf(t, "%02X ", pk.pkData[j]);
				thisES += t;
			}
			ES_listcontrol.InsertItem(listIndex,  PkIndex);
			ES_listcontrol.SetItem(listIndex, 1, LVIF_TEXT, _T("!"), 0, 0, 0, NULL); 
			//blankIndex[blankCount][0] = pk.pkNum;
			//blankIndex[blankCount][1] = sizeofThisES + PACKETSIZE-pk.count;
			//blankCount++;
			*/
		}

		UpdateData(FALSE);
		int index=0;
		//****************************** error check & print packet *******************************
		for(int i=0; i<intFileNumberOfPackets; i++)
		{

			byte buffer[PACKETSIZE];
			char t[10];
			char* indx;
			infile.Seek(i*sizeof(byte)*PACKETSIZE, infile.begin);   //���������� �ʱ�ȭ
			infile.Read(buffer, sizeof(byte)*PACKETSIZE);

			sprintf(indx, "%d", i);
			PkIndex = indx;


			if((int)buffer[0] != 71) // synbyte�� 47�� �ƴҰ��
			{
				for(index=0; index<PACKETSIZE; index++)
				{
					if((int)buffer[index] == 71) 
						break;
				}

				infile.Seek(i*sizeof(byte)*PACKETSIZE+index*sizeof(byte),infile.begin); // 47�� ������ �̵�
				infile.Read(buffer, sizeof(byte)*PACKETSIZE);
			}

			for(int j=0; j<60; j++) // print packet
			{
				t[0] = 0;
				sprintf(t, "%02X ", buffer[j]);
				PacketData1 += t;
			}

			for(int j=60; j<120; j++) // print packet
			{
				t[0] = 0;
				sprintf(t, "%02X ", buffer[j]);
				PacketData2 += t;
			}
			for(int j=120; j<PACKETSIZE; j++) // print packet
			{
				t[0] = 0;
				sprintf(t, "%02X ", buffer[j]);
				PacketData3 += t;
			}


			listIndex = i;
			TS_listcontrol.InsertItem(listIndex,  PkIndex);
			TS_listcontrol.SetItem(listIndex, 1, LVIF_TEXT, PacketData1, 0, 0, 0, NULL );
			TS_listcontrol.SetItem(listIndex, 2, LVIF_TEXT, PacketData2, 0, 0, 0, NULL );
			TS_listcontrol.SetItem(listIndex, 3, LVIF_TEXT, PacketData3, 0, 0, 0, NULL );

			PacketData1 = _T("");
			PacketData2 = _T("");
			PacketData3 = _T("");


			intFileErrorPackets = index;
			intFileNormalPackets = intFileNumberOfPackets - intFileErrorPackets;
		}
	}
}

//pid search
void CMPEGDlg::OnBnClickedPIDSearchButton()
{
	CString user = _T("");
	UpdateData(true);
	GetDlgItemTextW(Search_PID, user);

	intSearchPID = _ttoi(user);  
	TS_listcontrol.DeleteAllItems();

	int index=0;
	//******************************print packet *******************************
	for(int i=0; i<intFileNumberOfPackets; i++)
	{
		byte buffer[PACKETSIZE];
		char t[10];
		char* indx;
		infile.Seek(i*sizeof(byte)*PACKETSIZE, infile.begin);   //���������� �ʱ�ȭ
		infile.Read(buffer, sizeof(byte)*PACKETSIZE);
		Packet tempPK;
		tempPK.readData(buffer, i);
		if(tempPK.pid == intSearchPID)
		{
			sprintf(indx, "%d", i);
			PkIndex = indx;

			for(int j=0; j<60; j++) 
			{
				t[0] = 0;
				sprintf(t, "%02X ", tempPK.pkData[j]);
				PacketData1 += t;
			}
			for(int j=60; j<120; j++)
			{
				t[0] = 0;
				sprintf(t, "%02X ", tempPK.pkData[j]);
				PacketData2 += t;
			}
			TS_listcontrol.InsertItem(index,  PkIndex);
			TS_listcontrol.SetItem(index, 1, LVIF_TEXT, PacketData1, 0, 0, 0, NULL );
			TS_listcontrol.SetItem(index, 2, LVIF_TEXT, PacketData2, 0, 0, 0, NULL );
			for(int j=120; j<PACKETSIZE; j++) 
			{
				t[0] = 0;
				sprintf(t, "%02X ", tempPK.pkData[j]);
				PacketData3 += t;
			}
			TS_listcontrol.SetItem(index, 3, LVIF_TEXT, PacketData3, 0, 0, 0, NULL );
			index++;

			PacketData1 = _T("");
			PacketData2 = _T("");
			PacketData3 = _T("");
		}
	}
}

//Packet Number search
void CMPEGDlg::OnBnClickedPacketNumSearchButton()
{
	CString user = _T("");
	UpdateData(true);
	GetDlgItemTextW(Search_PacketNumber, user);

	intSearchPacketNumber = _ttoi(user);      
	TS_listcontrol.DeleteAllItems();

	int index=0;
	//******************************print packet *******************************
	for(int i=0; i<intFileNumberOfPackets; i++)
	{
		byte buffer[PACKETSIZE];
		char t[10];
		char* indx;
		infile.Seek(i*sizeof(byte)*PACKETSIZE, infile.begin);   //���������� �ʱ�ȭ
		infile.Read(buffer, sizeof(byte)*PACKETSIZE);
		Packet tempPK;
		tempPK.readData(buffer, i);

		if(tempPK.pkNum == intSearchPacketNumber)
		{
			if(intSearchPacketNumber > 10)
			{
				int l = intSearchPacketNumber-10;
				for(int k=l; k<intFileNumberOfPackets; k++)
				{
					infile.Seek(k*sizeof(byte)*PACKETSIZE, infile.begin);   //���������� �ʱ�ȭ
					infile.Read(buffer, sizeof(byte)*PACKETSIZE);
					tempPK.readData(buffer, k);
					sprintf(indx, "%d", k);
					PkIndex = indx;

					for(int j=0; j<60; j++) // print packet
					{
						t[0] = 0;
						sprintf(t, "%02X ", tempPK.pkData[j]);
						PacketData1 += t;
					}
					for(int j=60; j<120; j++) // print packet
					{
						t[0] = 0;
						sprintf(t, "%02X ", tempPK.pkData[j]);
						PacketData2 += t;
					}
					for(int j=120; j<PACKETSIZE; j++) // print packet
					{
						t[0] = 0;
						sprintf(t, "%02X ", tempPK.pkData[j]);
						PacketData3 += t;
					}

					TS_listcontrol.InsertItem(index,  PkIndex);
					TS_listcontrol.SetItem(index, 1, LVIF_TEXT, PacketData1, 0, 0, 0, NULL ); 
					TS_listcontrol.SetItem(index, 2, LVIF_TEXT, PacketData2, 0, 0, 0, NULL ); 
					TS_listcontrol.SetItem(index, 3, LVIF_TEXT, PacketData3, 0, 0, 0, NULL ); 
					index++;
					PacketData1 = _T("");
					PacketData2 = _T("");
					PacketData3 = _T("");
				}
				break;
			}
			else 
			{
				for(int k=0; k<intFileNumberOfPackets; k++)
				{
					sprintf(indx, "%d", k);
					PkIndex = indx;

					for(int j=0; j<60; j++) // print packet
					{
						t[0] = 0;
						sprintf(t, "%02X ", tempPK.pkData[j]);
						PacketData1 += t;
					}
					for(int j=60; j<120; j++) // print packet
					{
						t[0] = 0;
						sprintf(t, "%02X ", tempPK.pkData[j]);
						PacketData2 += t;
					}
					for(int j=120; j<PACKETSIZE; j++) // print packet
					{
						t[0] = 0;
						sprintf(t, "%02X ", tempPK.pkData[j]);
						PacketData3 += t;
					}

					TS_listcontrol.InsertItem(index,  PkIndex);
					TS_listcontrol.SetItem(index, 1, LVIF_TEXT, PacketData1, 0, 0, 0, NULL ); 
					TS_listcontrol.SetItem(index, 2, LVIF_TEXT, PacketData2, 0, 0, 0, NULL ); 
					TS_listcontrol.SetItem(index, 3, LVIF_TEXT, PacketData3, 0, 0, 0, NULL ); 
					index++;
					PacketData1 = _T("");
					PacketData2 = _T("");
					PacketData3 = _T("");
				}
				break;
			}
		}
	}
}

void CMPEGDlg::OnLvnItemchangedlist(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	*pResult = 0;

}

void CMPEGDlg::OnEnChangeEdit1()
{
	// TODO:  RICHEDIT ��Ʈ���� ���, �� ��Ʈ����
	// CDialogEx::OnInitDialog() �Լ��� ������ 
	//�ϰ� ����ũ�� OR �����Ͽ� ������ ENM_CHANGE �÷��׸� �����Ͽ� CRichEditCtrl().SetEventMask()�� ȣ������ ������
	// �� �˸� �޽����� ������ �ʽ��ϴ�.

	// TODO:  ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
}

//����Ʈ Ŭ������ ��
void CMPEGDlg::OnNMClicklist(NMHDR *pNMHDR, LRESULT *pResult)      
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	
	// ���û���
	TS_listcontrol.SetExtendedStyle(TS_listcontrol.GetExtendedStyle()|LVS_EX_FULLROWSELECT);

	int idx = 0;
		// ���� ���õ� idx ����
	idx = pNMItemActivate->iItem;
	if(idx != -1){
		CString number = TS_listcontrol.GetItemText(idx,0);
		CString data = TS_listcontrol.GetItemText(idx,1);

		thisID = _ttoi(number);      //CString -> int

		byte buf[PACKETSIZE];
		infile.Seek(sizeof(byte)*thisID*PACKETSIZE, infile.begin);   //���������� �̵�
		infile.Read(buf, sizeof(byte)*PACKETSIZE);
		pk.readData(buf, thisID);

		char temp[10];

		//initialize
		intSyncByte=_T("");
		intPID=_T("");
		intTransportErrorIndicator=_T("");
		intTransportScrambling=_T("");
		intPayloadUnitStart=_T("");
		intAdaptationFieldControl=_T("");
		intTransportPriority=_T("");
		intContinuityCounter=_T("");
		PSIinfo=_T("");
		Adapinfo=_T("");
		PESinfo=_T("");

		//insert selected packet data
		sprintf(temp, "%04x", pk.sync_byte);
		intSyncByte += temp;

		sprintf(temp, "%x", pk.transport_error_indicator);
		intTransportErrorIndicator += temp;

		sprintf(temp, "%x", pk.payload_unit_start_indicator);
		intPayloadUnitStart += temp;

		sprintf(temp, "%x", pk.transport_priority);
		intTransportPriority += temp;

		sprintf(temp, "%04x", pk.pid);
		intPID += temp;

		sprintf(temp, "%02x", pk.transport_scrambling_control);
		intTransportScrambling += temp;

		sprintf(temp, "%02x", pk.adaptation_field_control);
		intAdaptationFieldControl += temp;

		sprintf(temp, "%d", pk.continuity_counter);
		intContinuityCounter += temp;


		//---------------------PSI---------------------
		if(pk.pid == 0 || pk.pid == 1 || pk.pid==4128)
		{
			psi.calculatePSI(pk.pkData, pk.pid);

			char name[30];
			char tempPSI[40];

			//case of PSI
			switch(pk.pid)
			{
			case 0:      //PAT
				sprintf(name, "%s", "PAT(Program Allocation Table)");
				PSIinfo += name;
				PSIinfo += "\r\n";
				break;
			case 1:      //CAT
				sprintf(name, "%s", "CAT(Conditional Access Table)");
				PSIinfo += name;
				PSIinfo += "\r\n";
				break;
			case 4128:   //PMT
				sprintf(name, "%s", "PMT(Program Map Table)");
				PSIinfo += name;
				PSIinfo += "\r\n";
				break;
			default:
				break;
			}

			//first common data
			sprintf(name, "%s", "table id : ");
			sprintf(tempPSI, "%X", psi.table_id);
			PSIinfo += name;
			PSIinfo += tempPSI;
			PSIinfo += "\r\n";

			sprintf(name, "%s", "section syntax indicator : ");
			sprintf(tempPSI, "%X", psi.section_syntax_indicator);
			PSIinfo += name;
			PSIinfo += tempPSI;
			PSIinfo += "\r\n";

			sprintf(name, "%s", "section length : ");
			sprintf(tempPSI, "%X", psi.section_length);
			PSIinfo += name;
			PSIinfo += tempPSI;
			PSIinfo += "\r\n";

			//first divide data
			switch(pk.pid)
			{
			case 0:      //PAT
				// transport stream id 16;
				sprintf(name, "%s", "transport stream id : ");
				sprintf(tempPSI, "%X", psi.transport_stream_id);
				PSIinfo += name;
				PSIinfo += tempPSI;
				PSIinfo += "\r\n";
				break;
			case 1:      //CAT
				// reserved 16;
				break;
			case 4128:   //PMT
				// program number 16;
				sprintf(name, "%s", "program number : ");
				sprintf(tempPSI, "%X", psi.program_number);
				PSIinfo += name;
				PSIinfo += tempPSI;
				PSIinfo += "\r\n";
				break;
			default:
				break;
			}

			//second common data
			sprintf(name, "%s", "version number : ");
			sprintf(tempPSI, "%X", psi.version_number);
			PSIinfo += name;
			PSIinfo += tempPSI;
			PSIinfo += "\r\n";

			sprintf(name, "%s", "current next indicator : ");
			sprintf(tempPSI, "%X", psi.current_next_indicator);
			PSIinfo += name;
			PSIinfo += tempPSI;
			PSIinfo += "\r\n";

			sprintf(name, "%s", "section number : ");
			sprintf(tempPSI, "%X", psi.section_number);
			PSIinfo += name;
			PSIinfo += tempPSI;
			PSIinfo += "\r\n";

			sprintf(name, "%s", "last section number : ");
			sprintf(tempPSI, "%X", psi.last_section_number);
			PSIinfo += name;
			PSIinfo += tempPSI;
			PSIinfo += "\r\n";

			//second divde data
			switch(pk.pid)
			{
			case 0:         // PAT
				if(psi.calculate_length ==0)
					break;
				for(int j=0;j<psi.calculate_length;j++)
				{ 
					if(psi.program_number ==0)
					{
						// network PID 13;   
						sprintf(name, "%s", "program number : ");
						sprintf(tempPSI, "%X", j);
						PSIinfo += name;
						PSIinfo += tempPSI;
						PSIinfo += "\r\n";

						sprintf(name, "%s", "network PID : ");
						sprintf(tempPSI, "%X", psi.network_PID);
						PSIinfo += name;
						PSIinfo += tempPSI;
						PSIinfo += "\r\n";
					}

					else
					{
						// program map PID 13;   
						sprintf(name, "%s", "program number : ");
						sprintf(tempPSI, "%X", j);
						PSIinfo += name;
						PSIinfo += tempPSI;
						PSIinfo += "\r\n";

						sprintf(name, "%s", "Program map PID : ");
						sprintf(tempPSI, "%X", psi.program_map_PID);
						PSIinfo += name;
						PSIinfo += tempPSI;
						PSIinfo += "\r\n";
					}

				}
				//CRC32
				sprintf(name, "%s", "CRC32 : ");
				sprintf(tempPSI, "%x", psi.CRC_32);
				PSIinfo += name;
				PSIinfo += tempPSI;
				PSIinfo += "\r\n";
				break;
			case 1:         // CAT
				//CRC32
				sprintf(name, "%s", "CRC32 : ");
				sprintf(tempPSI, "%x", psi.CRC_32);
				PSIinfo += name;
				PSIinfo += tempPSI;
				PSIinfo += "\r\n";
				break;
			case 4128:      // PMT
				if(psi.calculate_length ==0)
					break;
				//etc
				break;
			default:
				break;
			}
		}
		else   //adaptation / PES
		{
			char name[30];
			char tempAdap[40];

			if(pk.adaptation_field_control == 2 || pk.adaptation_field_control == 3)  // Adaptation field ����
			{
				sprintf(name, "%s", "---Adaptation field---");
				Adapinfo += name;
				Adapinfo += "\r\n";

				sprintf(name, "%s", "adaptation field length : ");
				sprintf(tempAdap, "%X", pk.adaptation_field_length);
				Adapinfo += name;
				Adapinfo += tempAdap;
				Adapinfo += "\r\n";

				sprintf(name, "%s", "PCR flag : ");
				sprintf(tempAdap, "%X", pk.PCR_flag);
				Adapinfo += name;
				Adapinfo += tempAdap;
				Adapinfo += "\r\n";

				sprintf(name, "%s", "PCR : ");
				sprintf(tempAdap, "%X", pk.PCR_base);
				Adapinfo += name;
				Adapinfo += tempAdap;
				Adapinfo += "\r\n";

				if(pk.payload_unit_start_indicator ==1)               // PES ����
				{
					char tempPES[40];
					sprintf(name, "%s", "---PES header---");
					PESinfo += name;
					PESinfo += "\r\n";

					sprintf(name, "%s", "packet start code prefix : ");
					sprintf(tempPES, "%X", pk.packet_start_code_prefix);
					PESinfo += name;
					PESinfo += tempPES;
					PESinfo += "\r\n";

					sprintf(name, "%s", "stream id : ");
					sprintf(tempPES, "%X", pk.stream_id);
					PESinfo += name;
					PESinfo += tempPES;
					PESinfo += "\r\n";

					sprintf(name, "%s", "PES packet length : ");
					sprintf(tempPES, "%X", pk.PES_packet_length);
					PESinfo += name;
					PESinfo += tempPES;
					PESinfo += "\r\n";

					sprintf(name, "%s", "PTS/DTS flag : ");
					sprintf(tempPES, "%X", pk.PTS_DTS_flag);
					PESinfo += name;
					PESinfo += tempPES;
					PESinfo += "\r\n";

					if(pk.PTS_DTS_flag == 2)
					{
						sprintf(name, "%s", "PTS : ");
						sprintf(tempPES, "%X", pk.PTS);
						PESinfo += name;
						PESinfo += tempPES;
						PESinfo += "\r\n";
					}
					else if(pk.PTS_DTS_flag ==3)
					{
						sprintf(name, "%s", "PTS : ");
						sprintf(tempPES, "%X", pk.PTS);
						PESinfo += name;
						PESinfo += tempPES;
						PESinfo += "\r\n";

						sprintf(name, "%s", "DTS : ");
						sprintf(tempPES, "%X", pk.DTS);
						PESinfo += name;
						PESinfo += tempPES;
						PESinfo += "\r\n";
					}
					else
					{
						sprintf(name, "%s", "PTS/DTS error !!!");
						PESinfo += name;
						PESinfo += "\r\n";                  
					}
				}
			}
			else
			{
				if(pk.payload_unit_start_indicator ==1)
				{
					char tempPES[40];
					sprintf(name, "%s", "---PES header---");
					PESinfo += name;
					PESinfo += "\r\n";

					sprintf(name, "%s", "packet start code prefix : ");
					sprintf(tempPES, "%X", pk.packet_start_code_prefix);
					PESinfo += name;
					PESinfo += tempPES;
					PESinfo += "\r\n";

					sprintf(name, "%s", "stream id : ");
					sprintf(tempPES, "%X", pk.stream_id);
					PESinfo += name;
					PESinfo += tempPES;
					PESinfo += "\r\n";

					sprintf(name, "%s", "PES packet length : ");
					sprintf(tempPES, "%X", pk.PES_packet_length);
					PESinfo += name;
					PESinfo += tempPES;
					PESinfo += "\r\n";

					sprintf(name, "%s", "PTS/DTS flag : ");
					sprintf(tempPES, "%X", pk.PTS_DTS_flag);
					PESinfo += name;
					PESinfo += tempPES;
					PESinfo += "\r\n";

					if(pk.PTS_DTS_flag == 2)
					{
						sprintf(name, "%s", "PTS : ");
						sprintf(tempPES, "%X", pk.PTS);
						PESinfo += name;
						PESinfo += tempPES;
						PESinfo += "\r\n";
					}
					else if(pk.PTS_DTS_flag ==3)
					{
						sprintf(name, "%s", "PTS : ");
						sprintf(tempPES, "%X", pk.PTS);
						PESinfo += name;
						PESinfo += tempPES;
						PESinfo += "\r\n";

						sprintf(name, "%s", "DTS : ");
						sprintf(tempPES, "%X", pk.DTS);
						PESinfo += name;
						PESinfo += tempPES;
						PESinfo += "\r\n";
					}
					else
					{
						sprintf(name, "%s", "PTS/DTS error !!!");
						PESinfo += name;
						PESinfo += "\r\n";                  
					}
				}
			}
			PSIinfo += Adapinfo;
			PSIinfo += PESinfo;
		}


		OnEnChangePacketmap();
		UpdateData(false);
	}
	*pResult = 0;
}

//MAP ǥ��
void CMPEGDlg::OnEnChangePacketmap()
{
	// TODO:  RICHEDIT ��Ʈ���� ���, �� ��Ʈ����
	// CDialogEx::OnInitDialog() �Լ��� ������ 
	// �ϰ� ����ũ�� OR �����Ͽ� ������ ENM_CHANGE �÷��׸� �����Ͽ� CRichEditCtrl().SetEventMask()�� ȣ������ ������
	// �� �˸� �޽����� ������ �ʽ��ϴ�.

	// TODO:  ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.


}

//ES Mode control list 
void CMPEGDlg::OnMenuEsmode_ESMode()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_pwndShow = NULL;

	//ES_Mode ��Ȱ��ȭ
	
	intSyncByte = _T("");
	intPID = _T("");
	intTransportErrorIndicator = _T("");
	intTransportScrambling = _T("");
	intPayloadUnitStart = _T("");
	intAdaptationFieldControl = _T("");
	intTransportPriority = _T("");
	intContinuityCounter = _T("");
	PSIinfo = _T("");

	UpdateData(false);
	

	TS_listcontrol.ShowWindow(SW_HIDE);
	ES_listcontrol.ShowWindow(SW_SHOW);

	font.CreateFont(14, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, DEFAULT_CHARSET,
		OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS,
		_T("Consolas"));
	ES_listcontrol.SetFont(&font);

	//ES_listcontrol.DeleteAllItems();
	ES_listcontrol.SetExtendedStyle(LVS_EX_FULLROWSELECT);
	ES_listcontrol.SetExtendedStyle(LVS_EX_GRIDLINES);  

	ES_listcontrol.InsertColumn(0,_T("Packet No"), LVCFMT_RIGHT, 90);
	ES_listcontrol.InsertColumn(1,_T("ES Data"), LVCFMT_LEFT, 1000); 
	ES_listcontrol.InsertColumn(2,_T(""), LVCFMT_LEFT, 1000); 
	ES_listcontrol.InsertColumn(3,_T(""), LVCFMT_LEFT, 1000); 
	
	int ESCount=0;
	for(int i=0; i<intFileNumberOfPackets; i++)
	{
		byte buffer[PACKETSIZE];
		char t[10];
		char* indx;
		infile.Seek(i*sizeof(byte)*PACKETSIZE, infile.begin);   //���������� �ʱ�ȭ
		infile.Read(buffer, sizeof(byte)*PACKETSIZE);
		Packet ESpk;
		ESpk.readData(buffer, i);
		if(ESpk.pid != 0 && ESpk.pid != 1 && ESpk.pid != 4128 && ESpk.count<PACKETSIZE)
		{
			CString pkIndx;
			char tt[10];
			sprintf(tt, "%d", ESpk.pkNum);
			pkIndx = tt;
			CString thisESdata1 = _T("");
			CString thisESdata2 = _T("");
			CString thisESdata3 = _T("");
			for(int j=ESpk.count; j<ESpk.count+60; j++)
			{
				char t[10];
				sprintf(t, "%02x ", ESpk.ESData[j-ESpk.count]);
				thisESdata1 += t;
			}

			if(ESpk.count>64)
			{
				for(int j=ESpk.count+60; j<ESpk.count+120; j++)
				{
					char t[10];
					sprintf(t, "%02x ", ESpk.ESData[j-ESpk.count]);
					thisESdata2 += t;
				}
			}
			if(ESpk.count>124)
			{
				for(int j=ESpk.count+120; j<PACKETSIZE; j++)
				{
					char t[10];
					sprintf(t, "%02x ", ESpk.ESData[j-ESpk.count]);
					thisESdata3 += t;
				}
			}

			ES_listcontrol.InsertItem(ESCount,  pkIndx);
			ES_listcontrol.SetItem(ESCount, 1, LVIF_TEXT, thisESdata1, 0, 0, 0, NULL );
			ES_listcontrol.SetItem(ESCount, 2, LVIF_TEXT, thisESdata2, 0, 0, 0, NULL );
			ES_listcontrol.SetItem(ESCount, 3, LVIF_TEXT, thisESdata3, 0, 0, 0, NULL );
			ESCount++;
			
		}
	}
	
}

//TS_list �� customdraw
void CMPEGDlg::OnNMCustomdrawlist_TSlist(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMCUSTOMDRAW pNMCD;  
	pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);

	*pResult = 0;  

	LPNMLVCUSTOMDRAW  lplvcd = (LPNMLVCUSTOMDRAW)pNMHDR;  
	int iRow = (int)lplvcd->nmcd.dwItemSpec;  

	switch( lplvcd->nmcd.dwDrawStage )  
	{  
	case CDDS_PREPAINT :
		*pResult = CDRF_NOTIFYITEMDRAW;
		break;

	case CDDS_ITEMPREPAINT :
		lplvcd->clrText = RGB(0,0,0); 
		*pResult = CDRF_NOTIFYSUBITEMDRAW;  
		break;

		// Modify sub item text and/or background  
	case CDDS_SUBITEM | CDDS_PREPAINT | CDDS_ITEM :
		if ( iRow % 4 == 0 )
		{  
			lplvcd->clrTextBk = RGB(197, 243, 90);
		}
		else if( iRow % 4 == 2 )
		{
			lplvcd->clrTextBk = RGB(197, 192, 225); 
		}
		else
		{
			lplvcd->clrTextBk = RGB(255, 255, 255);
		}  

		*pResult = CDRF_DODEFAULT;
		break;
	}
}

//ES_list �� customdraw
void CMPEGDlg::OnNMCustomdrawlist_ESlist(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMCUSTOMDRAW pNMCD;  
	pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);

	*pResult = 0;  

	LPNMLVCUSTOMDRAW  lplvcd = (LPNMLVCUSTOMDRAW)pNMHDR;  
	int iRow = (int)lplvcd->nmcd.dwItemSpec;  

	switch( lplvcd->nmcd.dwDrawStage )  
	{  
	case CDDS_PREPAINT :
		*pResult = CDRF_NOTIFYITEMDRAW;
		break;

	case CDDS_ITEMPREPAINT :
		lplvcd->clrText = RGB(0,0,0); 
		*pResult = CDRF_NOTIFYSUBITEMDRAW;  
		break;

		// Modify sub item text and/or background  
	case CDDS_SUBITEM | CDDS_PREPAINT | CDDS_ITEM :
		if ( iRow % 4 == 0 )
		{  
			lplvcd->clrTextBk = RGB(255, 217, 236);
		}
		else if( iRow % 4 == 2 )
		{
			// ������ ���� ��
			lplvcd->clrTextBk = RGB(255, 224, 140); 
		}
		else
		{
			lplvcd->clrTextBk = RGB(255, 255, 255);
		}  

		*pResult = CDRF_DODEFAULT;
		break;
	}
}

//Packet Mode �� ��ȯ
void CMPEGDlg::OnMenuPacketmode_PacketMode()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	ES_listcontrol.ShowWindow(SW_HIDE);
	TS_listcontrol.ShowWindow(SW_SHOW);
}

//ES �˻�
void CMPEGDlg::OnBnClickedESSearchButton()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	//CString tempUser;
	CString user;
	CString search1;
	CString tempESdata;
	GetDlgItemTextW(Search_ES, user);	//�˻��� �Է� ����

	user.Replace(_T(" "), NULL);

	if(user.GetLength()>50)		//�˻�� 50�� �̻��� ���
		search1 = user.Left(50);	//�տ��� 50�� �߶� search1�� �ִ´�.
	else
		search1 = user;				//50�� ���� ������� �׳� search1�� �ִ´�.

	int i=0;
	while(true)
	{
		for(; i<totalESdata.GetLength(); i++)
		{
			CString temp;
			temp = totalESdata.Mid(i,search1.GetLength());	//�˻��� �� 50�ڿ� ES data�� 50�ڰ� ���� �κ��� �տ������� ã�´�.
			if(!temp.Compare(search1))
				break;
		}
		//���� �˻�� total ES data�� ��� ��ġ�������� �����ϴ��� �� �� �ִ�.
		tempESdata = totalESdata.Mid(i, user.GetLength());
		if(!tempESdata.Compare(user))
			break;
	}

	//���
	if(i<totalESdata.GetLength())	//�̶��� �˻�� ã�� ���
	{
		CString ESindex = _T("");
		CString ESdata = _T("");
		char* esIndex;
		char* esData;
		int listIndx=0;
		int start=0;
		int end=0;

		int size = i+user.GetLength();
		//�� i�� ���° ��Ŷ�� ���ԵȰ��� ã��
		for(int j=0; j<intFileNumberOfPackets-1; j++)
		{
			if((i>= blankIndex[j][1]) && (i < blankIndex[j+1][1]))
				start = blankIndex[j][0];
			if((size >= blankIndex[j][1]) && (size < blankIndex[j+1][1]))
				end = blankIndex[j][0];
		}
		for(int j=start; j<end; j++)
		{
			Packet pk;
			byte tempPK[PACKETSIZE];
			sprintf(esIndex, "%d", blankIndex[j][1]);		//��Ŷ�ѹ� ����
			ESindex = esIndex;
			infile.Seek(j*sizeof(byte), infile.begin);
			infile.Read(tempPK, PACKETSIZE);
			pk.readData(tempPK, j);

			for(int k=pk.count; k<PACKETSIZE; k++)
			{
				sprintf(esData, "%02x ", pk.pkData[k]);
				ESdata += esData;
			}

			ES_listcontrol.InsertItem(listIndx,  ESindex);
			ES_listcontrol.SetItem(listIndx, 1, LVIF_TEXT, ESdata, 0, 0, 0, NULL );
		}
		

	}

	else	//�˻�� ���� ����Ÿ �ȿ� �������� �ʴ°��
		AfxMessageBox(L"�˻�� ã�� �� �����ϴ�.");
}
