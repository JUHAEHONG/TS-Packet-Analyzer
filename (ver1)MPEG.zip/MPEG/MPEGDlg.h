
// MPEGDlg.h : ��� ����
//

#pragma once
#include "afxext.h"
#include "afxwin.h"
#include "afxcmn.h"


// CMPEGDlg ��ȭ ����
class CMPEGDlg : public CDialogEx
{
// �����Դϴ�.
public:
	CMPEGDlg(CWnd* pParent = NULL);	// ǥ�� �������Դϴ�.
	CString intSyncByte; 
	CString intTransportErrorIndicator;
	CString intPayloadUnitStart;
	CString intTransportPriority;
	CString intPID;
	CString intTransportScrambling;
	CString intAdaptationFieldControl;
	CString intContinuityCounter;
	CString intPacketNumber;
	
	CString PacketData1;
	CString PacketData2;
	CString PacketData3;
	
	int intSearchPID;
	int intSearchPacketNumber;
	int intFileSize;
	int intFileNumberOfPackets;
	int intFileNormalPackets;
	int intFileErrorPackets;
	int* errorPacketNum;
	int countError;
	CString PkIndex;
	int listIndex;
	int thisID;
	CString totalESdata;
	int** blankIndex;
	int blankCount;

public :
	CString PSIinfo;
	CString Adapinfo;
	CString PESinfo;

	CWnd* m_pwndShow;
	//int selectedRow;

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_MPEG_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �����Դϴ�.


// �����Դϴ�.
protected:
	HICON m_hIcon;

	// ������ �޽��� �� �Լ�
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEnChangePid();
	afx_msg void OnLbnSelchangelist();
	afx_msg void OnFileOpen_FileOpen();
	afx_msg void OnBnClickedPIDSearchButton();
	CBitmapButton Button1;
	afx_msg void OnBnClickedPacketNumSearchButton();
	CString User_PID; //����ڷκ��� PID �Է� �޾� ������ ����
	CString User_PacketNumber; //����ڷκ��� packetNumber �Է� �޾Ƽ� ������ ����
	CListCtrl TS_listcontrol;//listcontrol ����
	afx_msg void OnLvnItemchangedlist(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnEnChangeEdit1();
	afx_msg void OnNMClicklist(NMHDR *pNMHDR, LRESULT *pResult); //list control ���� �̺�Ʈ
	
	afx_msg void OnEnChangePacketmap();
	CBitmapButton Button2;
	CEdit inputPID;
	CBitmapButton Button4;
	CListCtrl ES_listcontrol;
	afx_msg void OnMenuEsmode_ESMode();
	afx_msg void OnNMCustomdrawlist_TSlist(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMCustomdrawlist_ESlist(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnMenuPacketmode_PacketMode();
	afx_msg void OnBnClickedESSearchButton();
};
