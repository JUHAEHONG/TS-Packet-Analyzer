#include "header.h"

byte* PES::setting(int n, byte* TSptr)
{
	byte* base_ptr = TSptr;
	byte* ptr = base_ptr;
	pkNum = n;

	packet_start_code_prefix = ptr[0]*0x10000 + ptr[1]*0x100 + ptr[2];

	stream_id = ptr[3];

	PES_packet_length = ptr[4]*0x100 + ptr[5];

	//if(PES_packet_length)
	{
		//PES_scrambling_control = (ptr[6]&0x30)>>4;

		//PES_priority = (ptr[6]&0x08)>>3;

		//data_alignment_indicator = (ptr[6]&0x04)>>2;

		//copyright = (ptr[6]&0x02) >> 1;

		//original_or_copy = ptr[6]&0x01;

		PTS_DTS_flag = (ptr[7]&0xC0)>>6;

		//ESCR_flag = (ptr[7]&0x20) >>5;

		//ES_rate_flag = (ptr[7]&0x10) >>4;

		//DSM_trick_mode_flag = (ptr[7]&0x08)>>3;

		//additional_copy_info_flag = (ptr[7]&0x04)>>2;

		//PES_CRC_flag = (ptr[7]&0x02) >>1;

		//PES_extension_flag = ptr[7]&0x01;

		ptr += 8;
		
		/* ���� ���� !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1 */
		if(PTS_DTS_flag == 2 || PTS_DTS_flag == 3)
		{
			PTS_32_30 = (ptr[0]&0x0E) >> 1;

			PTS_29_15 = ptr[1]*0xF0 + ((ptr[2]&0xFE) >> 1);

			PTS_14_0 = ptr[3]*0xF0 + ((ptr[4]&0xFE) >> 1) ;

			if(PTS_DTS_flag == 3)
			{
				DTS_32_30 = (ptr[5]&0x0E)>>1;
				
				DTS_29_15 = ptr[6]*0xF0 + ((ptr[7]&0xFE) >> 1);

				DTS_14_0 = ptr[8]*0xF0 + ((ptr[9]&0xFE) >> 1);

				ptr += 10;
			}

			ptr+=5;
		}

		/*
		if(ESCR_flag)
		{
			ESCR_reserved = (ptr[0]&0xC0)>>6;

			ESCR_32_30 = (ptr[0]&0x38)>>3;

			ESCR_29_15 = (ptr[0]&0x03)*0x2000 + (ptr[1]*0x20) + (ptr[2]&0xF8)>>4;

			ESCR_14_0 = (ptr[2]&0x03)*0x2000 + (ptr[3]*0x20) + (ptr[4]&0xF8)>>4;
			
			ptr += 6;
		}

		if(ES_rate_flag)
		{
			ES_rate = (ptr[0]&0xEF)*0x8000 + (ptr[1]*0x80) + (ptr[2]&0xFE)>>1;

			ptr += 3;
		}

		if(DSM_trick_mode_flag)
		{
			DSM_trick_mode_control = (ptr[0]&0xE0)>>5;

			if(DSM_trick_mode_control == 0 || DSM_trick_mode_control==3 )
			{
				field_id = (ptr[1]&0x18)>>3;
				intra_slice_refresh = (ptr[1]&0x04)>>2;
				frequency_truncation = ptr[1]&0x03;
			}
			else if(DSM_trick_mode_control ==1 || DSM_trick_mode_control==4)
			{
				req_ctrl = ptr[1]&&0x1F;
			}
			else if(DSM_trick_mode_control== 2)
			{
				field_id = (ptr[1]&0x18)>>3;

				DSM_reserved = ptr[1]&0x07;
			}
			else 
				DSM_reserved = ptr[1]&&0x1F;

			ptr+=2;
		}

		if(additional_copy_info_flag)
		{
			additional_copy_info = ptr[0]&0xEF;

			ptr +=1;
		}

		if(PES_CRC_flag)
		{
			previous_PES_CRC = ptr[0]*0x100 + ptr[1];

			ptr +=2;
		}
		if(PES_extension_flag)
		{
			PES_private_data_flag = (ptr[0]&0x80)>>7;

			pack_header_field_flag = (ptr[0]&0x40)>>6;

			program_packet_seq_counter_flag = (ptr[0]&0x20)>>5;

			P_STD_buffer_flag = (ptr[0]&0x10)>>4;

			PES_ext_reserved = (ptr[0]&0x0E)>>1;

			PES_extension_flag_2 = ptr[0]&0x01;

			ptr+=1;

			if(PES_private_data_flag)
			{
				PES_private_data_1 = ptr[0]*0x100 + ptr[1];
				PES_private_data_2 = ptr[2]*0x100 + ptr[3];
				
				ptr += 4;
			}

			if(pack_header_field_flag)
			{
				pack_field_length = ptr[0];

				ptr += pack_field_length +1;

			}

			if(program_packet_seq_counter_flag)
			{
				program_packet_seq_counter = ptr[0]&0xEF;
				

			}
		}*/
		
	}
	return base_ptr + PES_packet_length;
}

void PES::hasPTSDTS()
{
	if(PTS_DTS_flag==2)
	{
		PTS=0;
		PTS += PTS_32_30*0x40000000;
		PTS += PTS_29_15*0x4000;
		PTS += PTS_14_0;
	}
	else if(PTS_DTS_flag==3)
	{
		PTS=0;
		PTS += PTS_32_30*0x40000000;
		PTS += PTS_29_15*0x4000;
		PTS += PTS_14_0;

		DTS=0;
		DTS += DTS_32_30*0x40000000;
		DTS += DTS_29_15*0x4000;
		DTS += DTS_14_0;
	}
	else
	{
		PTS = -1;
		DTS = -1;
	}
}