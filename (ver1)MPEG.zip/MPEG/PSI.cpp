#include "header.h"

PSI::PSI()
{
	table_id=-1;
	section_syntax_indicator=-1;
	section_length=-1;
	
	//divide (PAT/PMT/CAT)
	transport_stream_id=-1;	// PAT
	program_number=-1;			// PMT
							// CAT : reserved

	//secnd common data
	version_number=-1;
	current_next_indicator=-1;
	section_number=-1;
	last_section_number=-1;

	//second divide data
	network_PID=-1;			// PAT 1
	program_map_PID=-1;		// PAT 2
	pcr_pid=-1;				// PMT
	program_info_length=-1;
	stream_type=-1;
	elementary_PID=-1;
	ES_info_length=-1;
	CRC_32=-1;					// common
}

void PSI::calculatePSI(byte pkData[188], int pid)
{
// continuity counter ���� byte ����
	// start common data
	
	calculate_length =0;

	// pointer field '0000 0000' 8;
	//int pointer_field = pk.pkData[4];

	// table id 8;
	table_id = pkData[5];
	// section syntax indicator 1;
	section_syntax_indicator = (pkData[6]&0x80)>>7;
	// '011' 3;
	// section length 12;
	section_length = (pkData[6]&0x0F)*0x100 + pkData[7];

	switch(pid)
	{
		case 0:		//PAT
			// transport stream id 16;
			transport_stream_id = pkData[8]*0x100 + pkData[9];
			break;
		case 1:		//CAT
			// reserved 16;
			break;
		case 4128:	//PMT
			// program number 16;
			program_number = pkData[8]*0x100 + pkData[9];
			break;
		default:
			break;
	}

	// '11' 2;
	// version number 5;
	version_number = (pkData[10]&0x3E)>>1;
	// current next indicator 1; /*pk.pkData[10]*/
	current_next_indicator = pkData[10]&0x01;
	// section number 8;
	section_number = pkData[11];
	// last section number 8;
	last_section_number = pkData[12];


	switch(pid)
	{
	case 0:			// PAT
		//caculate length
		calculate_length = ((int)section_length - 9)/4;
		
		if(calculate_length ==0)
			break;
		for(int i=0,j=0;j<calculate_length;i+=4,j++)
		{ 
			// '111' 3;
			// network PID 13;

			program_number = pkData[13+i]*0x100 + pkData[14+i];
			if(program_number ==0)
			{
				network_PID= (pkData[15+i]&0x1F)*0x100 + pkData[16+i];
			}
		// else
			// '111' 3;
			// program map PID 13;
			else
			{
			program_map_PID = (pkData[15+i]&0x1F)*0x100 + pkData[16+i];
			}
				
		}
		//CRC32 ������ pkData *4;
		CRC_32 = pkData[13+calculate_length *4]*0x1000000 + pkData[14+calculate_length *4]*0x10000 + pkData[15+calculate_length *4]*0x100 +pkData[16+calculate_length *4];
		break;
	case 1:			// CAT
		CRC_32 = pkData[13];
		break;
	case 4128:		// PMT
		//caculate length
		calculate_length = ((int)section_length - 9)/4;
		
		if(calculate_length ==0)
			break;
		
		/*
			'111' 3;
			PCR PID 13;	
			'1111' 4;
			program info length 12 -> �� ���ڸ��� '00';*/
			//program_info_length = pk.pkData[15] /**/ + pk.pkData[16];

		/*	n loop discriptor = progrm in fo length value;
			for length
				stream type 8;
				'111' 3;
				elementary PID 13;
				'1111' 4;
				ES info lenth 12;
				N loop descriptor = ES info lenth value
		*/

		// CRC32 = last pkData *4;
		break;
	default:
		break;
	}	
}