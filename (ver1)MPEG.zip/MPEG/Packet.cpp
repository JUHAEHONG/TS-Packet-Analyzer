#include "header.h"
#include "stdafx.h"

Packet::Packet()
{
	//isTrue = false;
}

void Packet::setData(byte arr[PACKETSIZE], int num)
{
	for(int i=0; i<PACKETSIZE; i++)
		pkData[i] = arr[i];
	pkNum = num;
}

/****************************************
���� n�� x��° ��Ʈ ���ϱ�
(n & (1<<x) ) >> x
******************************************/

void Packet::setPacket()
{
	sync_byte = pkData[0];		//set sync_byte
	
	transport_error_indicator = (pkData[1]&0x80) >> 7;	//set transport_error_indicator
	
	payload_unit_start_indicator = (pkData[1]&0x40) >> 6;	//set payload_unit_start_indicator

	transport_priority = (pkData[1]&0x20) >> 5;				//set transport_priority
									
	pid = (pkData[1]&0x1F)*0x100 + pkData[2];			//set PID

	transport_scrambling_control = (pkData[3]&0xC0)>>6;	//set transport_scrambling_control

	adaptation_field_control = (pkData[3]&0x30)>>4;		//set adaptation_field_control

	continuity_counter = pkData[3]&0x0F;		//set continuity_counter

	TSptr = &pkData[4];

	setAdaptation();

	setPES();

	setESsearch();
}

void Packet::printData()
{
	
	printf("#%d \n",pkNum);
	printf("%04X \n",sync_byte);
	printf("%01X \n",transport_error_indicator);
	printf("%01X \n",payload_unit_start_indicator);
	printf("%01X \n",transport_priority);
	printf("%d \n",pid);
	printf("%02X \n",transport_scrambling_control);
	printf("%02X \n",adaptation_field_control);
	printf("%02X \n",continuity_counter);
	printf("\n");

	//setAdaptation();
}

void Packet::readData(byte* temp, int n)
{
	//byte temp[PACKETSIZE];
	//isTrue = true;
	//fread(temp, sizeof(byte), PACKETSIZE, infile);
	setData(temp, n);
	setPacket();

}

int Packet::checkIsTrue()
{
	if((int)pkData[0] != 71)
		return pkNum;
	else
		return -1;
}

void Packet::setAdaptation()
{
	//printf("1111\n");
	if(adaptation_field_control == 2 || adaptation_field_control == 3 )
	{
	//	printf("2222\n");

		AdaptationField adapt;

		byte* ptr = TSptr;

		adapt.pkNum = pkNum;

		adaptation_field_length = pkData[4];

		//adapt.discontinuity_indicator =  (pkData[5] & (1 << 7)) >> 7;

		//adapt.random_access_indicator = (pkData[5] & (1 << 6)) >> 6;

		//adapt.elementart_stream_priority_indicator = (pkData[5] & (1 << 5)) >> 5;

		PCR_flag = (pkData[5] & (1 << 4)) >> 4;
		adapt.PCR_flag = PCR_flag;			// ���� ����.

		OPCR_flag = (pkData[5] & (1 << 3)) >> 3;

		splicing_flag = (pkData[5] & (1 << 2)) >> 2;

		transport_private_data_flag = (pkData[5] & (1 << 1)) >> 1;

		adaptation_field_extension_flag = (pkData[5] & (1 << 0)) >> 0;

		TSptr = &pkData[6];
		
		byte* temp;
		temp = adapt.setting(TSptr);

		TSptr = temp;
		TSptr += adaptation_field_length -1;						// ���� ����(�߰�)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		PCR_base = adapt.PCR_base;

		//150121 ���� �߰�
		adaptation_field_length = adapt.adaptation_field_length;

	}

	
}

void Packet::setPES()
{
	if(payload_unit_start_indicator && pid != 0 && pid != 1 && pid != 8191)
	{
		PES pes;
		byte* temp;
		temp = pes.setting(pkNum, TSptr);
		TSptr = temp;

		packet_start_code_prefix = pes.packet_start_code_prefix;
		stream_id = pes.stream_id;
		PES_packet_length = pes.PES_packet_length;
		PTS_DTS_flag = pes.PTS_DTS_flag;
		PES_header_data_length = pes.PES_header_data_length;	// 150121 �����߰�


		pes.hasPTSDTS();
		PTS = pes.PTS;
		DTS= pes.DTS;
	}
}

/* 150121 ���� �߰� */
void Packet::setESsearch()
{
	count = 4;

	if(adaptation_field_control == 2)					// adaptation field control �� 2�̸�, ES ����.
		count = 188;
	else if(adaptation_field_control == 3)				// adaptation field control �� 3�̸�, length ��ŭ �ִ�.
		count += adaptation_field_length;

	if(payload_unit_start_indicator)				// PES header�� �ִٸ�
	{
		count += 6;					// PES header�� ������ 48byte�� �߰�

		if(stream_id == 0)		//stream id�� padding �̸� padding data 8byte �� �߰�
			count += 1;
		else if(PES_packet_length ==0)		//PES packet length�� 0�̸� ���� �� �� ����.
		{
			count += 2;				// 7 flag�� ��Ÿ���� 8byte �߰�
			count += PES_header_data_length + 1;		// ���� �� ���� byte ���͸� ��Ÿ���� ������ ������ 8 byte �߰�.
		}
		else								// PES packet length�� ������ ���̶�� �� ���� �߰��Ѵ�.
			count += PES_packet_length+1;
	}

	TSptr = &pkData[count];

	for(int i=count; i<PACKETSIZE; i++)
	{
		ESData[i-count] = pkData[i]; 
	}
}