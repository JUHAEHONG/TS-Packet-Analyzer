#pragma once
#define PACKETSIZE 188

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <conio.h>
#include <sys/types.h>
#include <sys/stat.h>

typedef unsigned char byte;

class Packet 
{
public:
	int sync_byte;
	int transport_error_indicator;
	int payload_unit_start_indicator;
	int transport_priority;
	int pid;
	int transport_scrambling_control;
	int adaptation_field_control;
	int continuity_counter;
	byte pkData[PACKETSIZE];
	byte ESData[PACKETSIZE-4];
	int pkNum;
	byte* TSptr;
	int count;

	//adaptation / PES

	//adaptation
	int adaptation_field_length;
	char PCR_flag;
	char OPCR_flag;
	char splicing_flag;
	char transport_private_data_flag;
	char adaptation_field_extension_flag;

	long long PCR_base;		//33

	//PES
	int packet_start_code_prefix;
	int stream_id;
	int PES_packet_length;
	char PTS_DTS_flag;
	int PES_header_data_length;

	unsigned long long PTS;
	unsigned long long DTS;

	Packet();
	void setData(byte arr[PACKETSIZE], int num);
	void setPacket();
	void printData();
	int checkIsTrue();
	void readData(byte* temp, int n);
	void setAdaptation();
	void setPES();
	void setESsearch();
};

class AdaptationField 
{
public:
	AdaptationField()
	{}
	int pkNum;
	int adaptation_field_length;
	char PCR_flag;
	char OPCR_flag;
	char splicing_flag;
	char transport_private_data_flag;
	char adaptation_field_extension_flag;

	long long PCR;
	long long PCR_base;		//33
	long PCR_reserved;		//6
	long PCR_extension;		//9
	long long OPCR;
	long long OPCR_base;
	long OPCR_reserved;
	long OPCR_extension; 
	int splice_countdown;
	int transport_private_data_length;
	byte* transport_private_data;
	int adpatation_field_extension_length;
	char ltw_flag;
	char piecewise_rate_flag;
	char seamless_splice_flag;
	int reserved_1;
	char ltw_valid_flag;
	int ltw_offset;
	int reserved_2;
	int piecewise_rate;
	int splice_type;
	int DTS_next_au_32_30;
	int DTS_next_au_29_15;
	int DTS_next_au_14_0;
	
	//byte* ptr;

	byte* setting(byte* TSptr);
	//byte* getPtr();
};

class PES
{
public:
	PES(){}
	int pkNum;
	int packet_start_code_prefix;
	int stream_id;
	int PES_packet_length;

	char PTS_DTS_flag;
	int PTS_32_30;
	int PTS_29_15;
	int PTS_14_0;
	int DTS_32_30;
	int DTS_29_15;
	int DTS_14_0;
	int PES_header_data_length;
	unsigned long long PTS;
	unsigned long long DTS;

	byte* setting(int n, byte* TSptr);
	byte* getPtr();

	void hasPTSDTS();
};

class PSI
{
public:
	PSI();
	void calculatePSI(byte pkData[188], int pid);

	int table_id;
	int section_syntax_indicator;
	int section_length;
	
	//divide (PAT/PMT/CAT)
	int transport_stream_id;	// PAT
	int program_number;			// PMT
								// CAT : reserved

	//secnd common data
	int version_number;
	int current_next_indicator;
	int section_number;
	int last_section_number;

	//second divide data
	int network_PID;			// PAT 1
	int program_map_PID;		// PAT 2
	int pcr_pid;				// PMT
	int program_info_length;
	int stream_type;
	int elementary_PID;
	int ES_info_length;
	int CRC_32;					// common

	int calculate_length;
};